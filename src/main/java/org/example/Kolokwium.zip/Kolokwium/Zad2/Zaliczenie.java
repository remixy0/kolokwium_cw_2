package org.example.Zad2;

public class Zaliczenie {
    String przedmiot;
    int ocena;
    public Zaliczenie(String przedmiot, int ocena) {
        this.przedmiot = przedmiot;
        this.ocena = ocena;
    }

    public int getOcena() {
        return ocena;
    }
}
